export class Stocks {
	id: number;
	stockName: string;

	constructor(id: number, stockName: string){
    this.id = id;
    this.stockName = stockName;
  }
}