import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stocks-positions',
  templateUrl: './stocks-positions.component.html',
  styleUrls: ['./stocks-positions.component.css']
})
export class StocksPositionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
