import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StocksPositionsComponent } from './stocks-positions.component';

describe('StocksPositionsComponent', () => {
  let component: StocksPositionsComponent;
  let fixture: ComponentFixture<StocksPositionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StocksPositionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StocksPositionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
