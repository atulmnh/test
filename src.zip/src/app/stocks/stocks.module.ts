import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { StocksRoutingModule } from './stocks-routing.module';
import { StocksListComponent } from './stocks-list/stocks-list.component';
import { AddStocksComponent } from './add-stocks/add-stocks.component';
import { StocksDataComponent } from './stocks-data/stocks-data.component';
import { StocksPositionsComponent } from './stocks-positions/stocks-positions.component';
import { StocksMetadataComponent } from './stocks-metadata/stocks-metadata.component';

@NgModule({
  imports: [
    CommonModule,
    StocksRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [
  StocksListComponent
  ],
  declarations: [StocksListComponent, AddStocksComponent, StocksDataComponent, StocksPositionsComponent, StocksMetadataComponent]
})
export class StocksModule { }
