import { Component, OnInit } from '@angular/core';
import 'rxjs/add/operator/filter';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-stocks-data',
  templateUrl: './stocks-data.component.html',
  styleUrls: ['./stocks-data.component.css']
  
})
export class StocksDataComponent implements OnInit {

  stockName : String;
  isPositionsHidden: true;
  isDataHidden: true;

  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
  	this.route.queryParams
  		.filter(params => params.stockName)
  		.subscribe(params => {
  			console.log(params);

  			this.stockName = params.stockName;
  			console.log(this.stockName);
  		});
  }

  showDataOrPositions(){
  	this.isDataHidden = !this.isDataHidden;
  	this.isPositionsHidden = !this.isPositionsHidden;
  }

}
