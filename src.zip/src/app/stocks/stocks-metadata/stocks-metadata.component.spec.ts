import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StocksMetadataComponent } from './stocks-metadata.component';

describe('StocksMetadataComponent', () => {
  let component: StocksMetadataComponent;
  let fixture: ComponentFixture<StocksMetadataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StocksMetadataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StocksMetadataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
