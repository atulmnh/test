import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stocks-metadata',
  templateUrl: './stocks-metadata.component.html',
  styleUrls: ['./stocks-metadata.component.css']
})
export class StocksMetadataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
