import { Component, OnInit } from '@angular/core';
import { Stocks } from '../stocks';
import { StocksService } from '../stocks.service';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-stocks-list',
  templateUrl: './stocks-list.component.html',
  styleUrls: ['./stocks-list.component.css'],
  providers: [StocksService]
})
export class StocksListComponent implements OnInit {

  private stocks: Stocks[];
  private subscription: Subscription;

  constructor(private stocksService: StocksService) { 
  	this.subscription = this.stocksService.findAll().subscribe(
  		stocks => {
  			this.stocks = stocks;
  		}
  	);
  }

  ngOnInit() {
  	this.getAllStocks();
  }

  getAllStocks(){
  	this.stocksService.findAll().subscribe(
  		stocks => {
  			this.stocks = stocks;
  		},

  		err => {
  			console.log(err);
  		}
  	);
  }

  myEvent(){
  	alert("hell");
  }
}
