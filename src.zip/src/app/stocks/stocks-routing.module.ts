import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StocksListComponent } from './stocks-list/stocks-list.component';
import { AddStocksComponent } from './add-stocks/add-stocks.component';
import { StocksDataComponent } from './stocks-data/stocks-data.component';

const routes: Routes = [
	//{ path: 'stocks', component: StocksListComponent },
	{ path: 'stocks/add', component: AddStocksComponent },
	{ path: 'stocks/edit/:id', component: AddStocksComponent },
	{ path: 'stocks/stocksdata', component: StocksDataComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StocksRoutingModule { }
