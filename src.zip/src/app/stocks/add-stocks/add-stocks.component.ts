import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { StocksService } from '../stocks.service';
import { Stocks } from "../stocks";
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-add-stocks',
  templateUrl: './add-stocks.component.html',
  styleUrls: ['./add-stocks.component.css'],
  providers: [StocksService]
})
export class AddStocksComponent implements OnInit {

	id: number;
	stock: Stocks;

	addStockForm: FormGroup;

  constructor( private route: ActivatedRoute,
  			   private router: Router,
  			   private stocksService: StocksService ) {	}

  ngOnInit() {

  	this.addStockForm = new FormGroup({
  		stockNameInput: new FormControl()
  	});
  }

  ngOnDestroy(): void {
    //this.sub.unsubscribe();
  }

  onSubmit(){
  	let stock: Stocks = new Stocks(null, 
  	this.addStockForm.controls['stockNameInput'].value;

  	this.stocksService.addStock(stock).subscribe();
  	this.addStockForm.reset();
  	this.router.navigate(['/']);
  }

}
