import { Injectable } from '@angular/core';
import { Stocks } from './stocks';
import { Http, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class StocksService {

  private apiUrl = 'http://localhost:8080/dashva/stocks';

  constructor(private http: Http) { }

  findAll(): Observable<Stocks[]> {
   return this.http.get(this.apiUrl)
   	.map((res:Response) => res.json())
   	.catch((error:any) => Observable.throw(error.json().error || 'Server error'));
  }

  findById(id: number): Observable<Stocks> {
    return null;
  }
 
  addStock(stock: Stocks): Observable<Stocks> {
    return this.http.post(this.apiUrl, stock)
    	.catch((error:any) => Observable.throw(error.json || 'Server error'));
  }
 
  deleteUserById(id: number): Observable<boolean> {
    return null;
  }
 
  updateUser(stock: Stocks): Observable<Stocks> {
    return null;
  }

}
