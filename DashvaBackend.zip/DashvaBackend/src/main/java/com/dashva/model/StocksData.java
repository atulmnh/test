package com.dashva.model;

import java.util.Date;

public class StocksData {
	
	private Long id;
	private Date date;
	private String stock_name;
	private Float price;
	
	public StocksData(long id, String stock_name, Date date, Float price){
		this.id = id;
		this.date = date;
		this.stock_name = stock_name;
		this.price = price;
	}
	
	public StocksData(){
		
	}
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getStock_name() {
		return stock_name;
	}
	public void setStock_name(String stock_name) {
		this.stock_name = stock_name;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	@Override
	public String toString(){
		return "StockData [id=" + id + ", stock_name" + stock_name + 
				", date=" + date + ", price=" + price + "]";
	}
}
