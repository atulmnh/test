package com.dashva.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.dashva.model.StocksData;

@Component
public class StocksDataDao {

	private static List<StocksData> stocksdataList;
	{
		Date date = Calendar.getInstance().getTime();
		
		stocksdataList = new ArrayList<StocksData>();
		stocksdataList.add(new StocksData(101, "Ajanta Pharma", date, 1000.00F));
		stocksdataList.add(new StocksData(202, "Cera", date, 2000.00F));
		stocksdataList.add(new StocksData(101, "Vedanta", date, 3000.00F));
	}
	
	/**
	 * Create new customer in dummy database. Updates the id and insert new
	 * customer in list.
	 * 
	 * @param customer
	 *            Customer object
	 * @return customer object with updated id
	 */
	public StocksData create(StocksData stockData) {
		stockData.setId(System.currentTimeMillis());
		stocksdataList.add(stockData);
		return stockData;
	}
}
