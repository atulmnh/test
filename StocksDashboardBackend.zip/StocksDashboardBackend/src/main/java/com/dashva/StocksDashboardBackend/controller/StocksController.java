package com.dashva.StocksDashboardBackend.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.dashva.StocksDashboardBackend.model.Stocks;
import com.dashva.StocksDashboardBackend.repository.StocksRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/dashva")
public class StocksController {

	@Autowired
	StocksRepository stocksRepository;
	
	private List<Stocks> stocks = new ArrayList();
	
	@GetMapping("/stocks")
	public List<Stocks> getAllStocks(){
		return stocksRepository.findAll();
	}
	
	@PostMapping("/stocks")
	public Stocks addStock(@Valid @RequestBody Stocks stock){
		stock.setId(4L);
		return stocksRepository.save(stock);
	}
	
	
}
