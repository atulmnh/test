package com.dashva.StocksDashboardBackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dashva.StocksDashboardBackend.model.Stocks;

@Repository
public interface StocksRepository extends JpaRepository<Stocks, Long>{

}
