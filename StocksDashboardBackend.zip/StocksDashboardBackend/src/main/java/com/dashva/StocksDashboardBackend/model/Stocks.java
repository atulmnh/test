package com.dashva.StocksDashboardBackend.model;

import java.io.Serializable;

import javax.persistence.*;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="stocks")
@EntityListeners(AuditingEntityListener.class)
public class Stocks implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 121212L;

	@Id
	private Long id;
	
	private String stockName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStockName() {
		return stockName;
	}

	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	
}
