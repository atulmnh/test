package com.dashva.StocksDashboardBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StocksDashboardBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(StocksDashboardBackendApplication.class, args);
	}
}
